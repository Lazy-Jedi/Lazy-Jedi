using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Services.Authentication;
using Unity.Services.Core;

namespace LazyJedi.Cloud
{
    /// <summary>
    /// Make sure you Initialize the Unity and Authentication services before using this class.
    /// </summary>
    public static class UnityAuthentication
    {
        #region PROPERTIES

        public static IAuthenticationService Service { get; private set; } = AuthenticationService.Instance;

        public static string AccessToken
        {
            get => Service.AccessToken;
        }

        public static string PlayerID
        {
            get => Service.PlayerId;
        }

        public static string PlayerName
        {
            get => Service.PlayerName;
        }

        public static PlayerInfo PlayerInfo
        {
            get => Service.PlayerInfo;
        }

        public static bool IsSignedIn
        {
            get => Service.IsSignedIn;
        }

        #endregion

        #region MISC METHODS

        public static void RegisterSignInFailed(Action<RequestFailedException> signInFailed)
        {
            AuthenticationService.Instance.SignInFailed += signInFailed;
        }

        public static void UnregisterSignInFailed(Action<RequestFailedException> signInFailed)
        {
            AuthenticationService.Instance.SignInFailed -= signInFailed;
        }

        public static void RegisterSignInSucceeded(Action signedIn)
        {
            AuthenticationService.Instance.SignedIn += signedIn;
        }

        public static void UnregisterSignInSucceeded(Action signedIn)
        {
            AuthenticationService.Instance.SignedIn -= signedIn;
        }

        public static void RegisterSignOutSucceeded(Action signedOut)
        {
            AuthenticationService.Instance.SignedOut += signedOut;
        }

        public static void UnregisterSignOutSucceeded(Action signedOut)
        {
            AuthenticationService.Instance.SignedOut -= signedOut;
        }

        #endregion

        #region SIGN-IN ANONYMOUSLY METHOD

        public static async Task AnonymousLogin()
        {
            await AuthenticationService.Instance.SignInAnonymouslyAsync();
        }

        #endregion


        #region SIGN-IN WITH GOOGLE METHODS

        public static async Task GoogleLogin(string tokenID, SignInOptions signInOptions = null)
        {
            await AuthenticationService.Instance.SignInWithGoogleAsync(tokenID, signInOptions);
        }

        public static async Task GoogleLogin(string tokenID, LinkOptions linkOptions = null)
        {
            await AuthenticationService.Instance.LinkWithGoogleAsync(tokenID, linkOptions);
        }

        #endregion


        #region SIGN OUT METHODS

        public static void SignOut(bool clearCredentials = false)
        {
            AuthenticationService.Instance.SignOut(clearCredentials);
        }

        #endregion
    }
}