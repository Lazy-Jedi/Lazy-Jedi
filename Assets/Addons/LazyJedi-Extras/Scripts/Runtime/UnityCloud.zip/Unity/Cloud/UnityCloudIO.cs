using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LazyJedi.Extensions;
using Newtonsoft.Json;
using Unity.Services.CloudSave;
using UnityEngine;

namespace LazyJedi.Cloud
{
    /// <summary>
    /// Make sure that Unity and Authentication Services have been initialized before using UnityIO
    /// </summary>
    public static class UnityCloudIO
    {
        #region CLOUD SAVE METHODS

        /// <summary>
        /// Upload a single key and value to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="key">The key identity of the value to upload</param>
        /// <param name="value">The value object to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(string key, object value)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(new Dictionary<string, object> { { key, value } });
        }

        /// <summary>
        /// Upload a single key-value pair to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="pair">The key-value pair to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(KeyValuePair<string, object> pair)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(new Dictionary<string, object> { { pair.Key, pair.Value } });
        }

        /// <summary>
        /// Upload an array of key-value tuples to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="data">An array of key-value tuples to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save((string key, object value)[] data)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(data.ToDictionary(pair => pair.key, pair => pair.value));
        }

        /// <summary>
        /// Upload a list of key-value tuples to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="data">A list of key-value tuples to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(List<(string key, object value)> data)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(data.ToDictionary(pair => pair.key, pair => pair.value));
        }

        /// <summary>
        /// Upload an array of key-value pairs to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="data">An array of key-value pairs to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(KeyValuePair<string, object>[] data)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(data.ToDictionary(pair => pair.Key, pair => pair.Value));
        }

        /// <summary>
        /// Upload a list of key-value pairs to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="data">A list of key-value pairs to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(List<KeyValuePair<string, object>> data)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(data.ToDictionary(pair => pair.Key, pair => pair.Value));
        }

        /// <summary>
        /// Upload one or more key-value pairs to the Cloud Save service, overwriting any values
        /// that are currently stored under the given keys.
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        ///
        /// <code>Dictionary</code> as a parameter ensures the uniqueness of given keys.
        /// There is no client validation in place, which means the API can be called regardless if data is incorrect and/or missing.
        /// </summary>
        /// <param name="data">The data to upload</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Save(Dictionary<string, object> data)
        {
            await CloudSaveService.Instance.Data.ForceSaveAsync(data);
        }

        #endregion

        #region CLOUD LOAD METHODS

        /// <summary>
        /// Downloads a single value from Cloud Save, based on the provided key.<br></br>
        /// There is no client validation in place.<br></br>
        /// This method includes pagination.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        /// </summary>
        /// <param name="key">The key to download from the server</param>
        /// <param name="useNewtonsoft">A flag used to Deserialize the Data with either the builtin JsonUtility or the Newtonsoft Library</param>
        /// <returns>The object-value that represents the current state of data on the server</returns>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task<T> Load<T>(string key, bool useNewtonsoft = false)
        {
            Dictionary<string, string> query = await CloudSaveService.Instance.Data.LoadAsync(new HashSet<string> { key });
            if (query.TryGetValue(key, out string value))
            {
                return Deserialize<T>(useNewtonsoft, value);
            }
            Debug.unityLogger.LogError("Load", $"There is no such key: {key}");
            return default;
        }

        /// <summary>
        /// Downloads one or more values from Cloud Save, based on the provided hashset of keys.<br></br>
        /// There is no client validation in place.<br></br>
        /// This method includes pagination.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        /// </summary>
        /// <param name="keys">The hashset of keys to download from the server</param>
        /// <param name="useNewtonsoft">A flag used to Deserialize the Data with either the builtin JsonUtility or the Newtonsoft Library</param>
        /// <returns>The object-value that represents the current state of data on the server</returns>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task<Dictionary<string, object>> Load(HashSet<string> keys, bool useNewtonsoft = false)
        {
            Dictionary<string, string> query = await CloudSaveService.Instance.Data.LoadAsync(keys);
            Dictionary<string, object> results = new Dictionary<string, object>();
            foreach (KeyValuePair<string, string> pair in query)
            {
                if (query.TryGetValue(pair.Key, out string value))
                {
                    results.Add(pair.Key, Deserialize<object>(useNewtonsoft, value));
                }
            }
            return results;
        }

        /// <summary>
        /// Downloads one or more values from Cloud Save, based on the provided dictionary,
        /// for each valid key in the dictionary the corresponding object will be downloaded.<br></br>
        /// There is no client validation in place.<br></br>
        /// This method includes pagination.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        /// </summary>
        /// <param name="data">The dictionary of valid keys to download from the server</param>
        /// <param name="useNewtonsoft">A flag used to Deserialize the Data with either the builtin JsonUtility or the Newtonsoft Library</param>
        /// <returns>The object-value that represents the current state of data on the server</returns>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Load(Dictionary<string, object> data, bool useNewtonsoft = false)
        {
            Dictionary<string, string> query = await CloudSaveService.Instance.Data.LoadAsync(data.Keys.ToHashSet());
            foreach (KeyValuePair<string, string> pair in query)
            {
                if (!pair.Value.IsNullOrEmpty())
                {
                    data[pair.Key] = Deserialize<object>(useNewtonsoft, pair.Value);
                }
                else
                {
                    data.Remove(pair.Key);
                }
            }
        }

        #endregion

        #region OVERWRITE METHODS

        /// <summary>
        /// Downloads a single value from Cloud Save, based on the provided key,<br></br>
        /// and overwrites the provided object with the downloaded data.<br></br>
        /// There is no client validation in place.<br></br>
        /// This method includes pagination.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        /// </summary>
        /// <param name="key">The key to download from the server</param>
        /// <param name="object">The object that will be overwritten by the downloaded data</param>
        /// <returns>The object-value that represents the current state of data on the server</returns>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Overwrite<T>(string key, T @object)
        {
            Dictionary<string, string> query = await CloudSaveService.Instance.Data.LoadAsync(new HashSet<string> { key });
            if (query.TryGetValue(key, out string value))
            {
                JsonUtility.FromJsonOverwrite(value, @object);
            }
        }

        /// <summary>
        /// Downloads one or more values from Cloud Save, based on the provided keys,<br></br>
        /// and overwrites the provided objects with the downloaded data.<br></br>
        /// There is no client validation in place.<br></br>
        /// This method includes pagination.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.
        /// </summary>
        /// <param name="objects">The dictionary of key-value pairs that are downloaded from the server</param>
        /// <returns>The object-value that represents the current state of data on the server</returns>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Overwrite(Dictionary<string, object> objects)
        {
            Dictionary<string, string> query = await CloudSaveService.Instance.Data.LoadAsync(objects.Keys.ToHashSet());
            foreach (KeyValuePair<string, string> pair in query)
            {
                if (query.TryGetValue(pair.Key, out string value))
                {
                    JsonUtility.FromJsonOverwrite(value, objects[pair.Key]);
                }
            }
        }

        #endregion

        #region DELETE METHODS

        /// <summary>
        /// Removes the given key. If a given key doesn't exist, there is no feedback in place to inform a developer about it.<br></br>
        /// There is no client validation implemented for this method.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        ///
        /// </summary>
        /// <param name="key">The key to be removed from the server</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Delete(string key)
        {
            await CloudSaveService.Instance.Data.ForceDeleteAsync(key);
        }

        /// <summary>
        /// Removes one key at the time. If a given key doesn't exist, there is no feedback in place to inform a developer about it.<br></br>
        /// There is no client validation implemented for this method.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        ///
        /// </summary>
        /// <param name="keys">The keys to be removed from the server</param>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task Delete(HashSet<string> keys)
        {
            List<Task> deleteTasks = keys.Select(async key => await Delete(key)).ToList();
            await Task.WhenAll(deleteTasks);
        }

        /// <summary>
        /// Removes all the saved data. If a given key doesn't exist, there is no feedback in place to inform a developer about it.<br></br>
        /// There is no client validation implemented for this method.<br></br>
        /// Throws a CloudSaveException with a reason code and explanation of what happened.<br></br>
        ///
        /// </summary>
        /// <exception cref="CloudSaveException">Thrown if request is unsuccessful.</exception>
        /// <exception cref="CloudSaveValidationException">Thrown if the service returned validation error.</exception>
        /// <exception cref="CloudSaveRateLimitedException">Thrown if the service returned rate limited error.</exception>
        public static async Task DeleteAll()
        {
            List<string> keys = await CloudSaveService.Instance.Data.RetrieveAllKeysAsync();
            List<Task> deleteTasks = keys.Select(async key => await Delete(key)).ToList();
            await Task.WhenAll(deleteTasks);
        }

        #endregion

        #region HELPER METHODS

        private static T Deserialize<T>(bool useNewtonsoft, string value)
        {
            return useNewtonsoft ? JsonConvert.DeserializeObject<T>(value) : value.FromJson<T>();
        }

        #endregion
    }
}